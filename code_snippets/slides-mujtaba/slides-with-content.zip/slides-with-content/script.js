// your script file for adding your own jquery
$(function() {
// Your Code from here on down. Don't delete that line above!
  


$('.single-slide').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 5000,
  infinite: true,
  dots: true
});












// End of Your Code . Don't delete that line below!!
});