$(function(){
    alert('jquery is working!');//
    
});