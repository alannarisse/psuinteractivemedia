View this in effect at <a href="https://psuinteractivemedia.com/code_snippets/css-card-effect/" target="_blank">This url</a>
