//$('#mysvg').on('click', function(){
//    $(this).toggleClass('yellow-bg');
//})
//
//$('#mysvg').on('mouseover', function(){
//    $(this).addClass('pink');
//})
//$('#mysvg').on('mouseout', function(){
//    $(this).removeClass('pink');
//})
$('#mysvg').on('click', function(){
    $('.cls-1').css('fill', 'red');
})