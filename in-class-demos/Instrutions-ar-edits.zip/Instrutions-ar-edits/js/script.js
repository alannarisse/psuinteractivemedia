// your script file for adding your own jquery
$(function() {
// Your Code from here on down. Don't delete that line above!
  














// End of Your Code . Don't delete that line below!!
});