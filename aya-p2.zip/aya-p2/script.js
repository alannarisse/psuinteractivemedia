$(document).ready(function(){
  $('.hero-home').slick({
    autoplay: true,
    autoplaySpeed: 1000,
    dots: true,
  });
});
		