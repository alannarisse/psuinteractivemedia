This is my first fully functional app, a basic quiz app.
